<?php


  $aux1='{"project":"myLittleProject","file":"prod-versions\/myLittleProject.ver","cwd":"\/var\/www\/html","error":"Not found"}';

  $aux2=' [ { "key": 100, "value1": "a"}, { "key": 200, "value1": "b", "value2": "t"}] ';

  $aux3=' { "x": { "key": 100, "value1": "a"}, "y": { "key": 200, "value1": "b", "value2": "t"} } ';

  $aux4 = '{ "a": { "j": 100}, "b": {"k": 200} }';

  function mostrar($aux) {
    echo "$aux\n--------\n";

    $data=json_decode($aux,true);

    print_r($data);

    $first_key = key($data);

    $isArray = is_array($data[$first_key]);
    echo "is_array() ?= ".intval($isArray)."\n";
    $isInt = is_int($first_key);
    if (($isInt) && ($isArray)) {
      reset($data[$first_key]);
      $first_key = key($data[$first_key]);
      $isInt = is_int($first_key);
    }

    echo "first_key=$first_key\n";    

    echo "isInt(first_key)? = ".intval($isInt)."\n\n";

    $csvHeader = "";
    $csvData = array();
    $csvLineNdx = 0;
    if (!$isArray) {
      $csvData[$csvLineNdx]='';
      foreach ($data as $key => $value) {
        $csvHeader.=$key.';';
        $csvData[$csvLineNdx].=($value).';';
      }    
    } else {
      $keyList = array();
      if ($isInt==0) {
        $keyList[]="_id_";
      }
      foreach ($data as $key => $value) {
        if (is_array($value)) {
          foreach ($value as $k1 => $v2) {
            if (!in_array($k1, $keyList))
              $keyList[]=$k1;
          }
        } else {
          if (!in_array($key, $keyList))
            $keyList[]=$key;
        }
      }
      print_r($keyList);

      /* header */
      $csvHeader = join($keyList,';');

      /* lines */
      foreach($data as $key=>$value) {
        $csvData[$csvLineNdx]='';
        if (!$isInt) {
          $csvData[$csvLineNdx].=$key.";";
        }
        if (is_array($value)) {
          foreach($keyList as $keyName) {
            $csvData[$csvLineNdx].=(isset($value[$keyName])?$value[$keyName]:'null').';';
          }
        } else {
          /* pelas contas, deveria de ter alguma coisa aqui... mas o que? */
        }
        $csvLineNdx++;
      }
    }

    echo "CSV --------------------------\n";

    echo rtrim($csvHeader,';')."\n";
    foreach($csvData as $csvLine) {
      echo rtrim($csvLine, ';')."\n";
    }

    echo "------------------------------\n\n";

  }

  mostrar($aux1);
  mostrar($aux2);
  mostrar($aux3);
  mostrar($aux4);
?>
